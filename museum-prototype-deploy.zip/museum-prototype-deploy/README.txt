我的思政博物馆 V5.1 — 静态网站部署包

部署方式（GitHub Pages）：
1. 在 GitHub 新建一个 repository（建议名：museum-prototype）。
2. 上传 index.html 到仓库根目录。
3. 打开仓库 Settings → Pages。
4. 在 Build and deployment 中选择 Deploy from a branch。
5. Branch 选择 main，文件夹选择 /(root)，点击 Save。
6. 等待部署完成，GitHub Pages 会显示公开访问网址。

说明：这是单文件静态 HTML 原型；当前 AI 对话、图片生成和 3D 展馆为模拟交互，未连接真实生成服务。
